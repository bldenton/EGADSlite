#!/bin/bash

# Compile Code
make clean
make

# Run code with all options
./egadslite_face_param_err complex.egadslite

