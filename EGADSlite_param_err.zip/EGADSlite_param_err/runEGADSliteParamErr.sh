#!/bin/bash

# Compile Code
make clean
make

# Run code with all options
./egadslite_param_err Nozzle_fromStep.egadslite

